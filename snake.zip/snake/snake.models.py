#snake хранит двумерный массив, положение клеток змейки
def severed_tail(snake, apple, direction, x_max, y_max):
  x_apple, y_apple = apple
  x_snake, y_snake = snake[0][0] + direction[0], snake[0][1] + direction[1]
  x_snake = 0 if x_snake > x_max else x_max if x_snake < 0 else x_snake
  y_snake = 0 if y_snake > y_max else y_max if y_snake < 0 else y_snake
  if x_snake == x_apple and y_snake == y_apple:
    set_new_coords_apple(apple)
  elif [x_snake, y_snake] in snake:
    snake = []
  else:
    snake.pop()
  snake.insert(0, [x_snake, y_snake])
